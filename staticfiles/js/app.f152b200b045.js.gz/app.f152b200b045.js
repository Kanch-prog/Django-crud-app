document.querySelector('.logout-link').addEventListener('click', function(event) {
    event.preventDefault(); // Prevent the default link behavior
    document.getElementById('logout-form').submit(); // Submit the form
});
